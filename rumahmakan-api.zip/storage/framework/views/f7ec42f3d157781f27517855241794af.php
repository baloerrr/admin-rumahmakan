<?php $__env->startSection('content'); ?>
    <div class="container col-md-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex" style="align-items: center; justify-content: space-between">
                <h6 class="m-0 font-weight-bold text-primary">Edit Data Movie</h6>
                <a class="btn btn-primary" href="<?php echo e(route('movie.index')); ?>">Back</a>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('movie.update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="judul" class="form-label">Judul:</label>
                                <input type="text" id="judul" name="judul" class="form-control" value="<?php echo e($item->judul); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="banner" class="form-label">Banner:</label>
                                <input type="file" id="banner" name="banner" class="form-control" accept="image/*">
                            </div>
                            <div class="mb-3">
                                <label for="video" class="form-label">Video:</label>
                                <input type="file" id="video" name="video" class="form-control" accept="video/*">
                            </div>
                            <div class="mb-3">
                                <label for="tipe" class="form-label">Tipe:</label>
                                <input type="text" id="tipe" name="tipe" class="form-control" value="<?php echo e($item->tipe); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="desk" class="form-label">Deskripsi:</label>
                                <textarea id="desk" name="desk" class="form-control" rows="4" required><?php echo e($item->desk); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rumahmakan-api\resources\views/movie/edit.blade.php ENDPATH**/ ?>