<?php $__env->startSection('content'); ?>
    <div class="container col-md-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex" style="align-items: center; justify-content: space-between">
                <h6 class="m-0 font-weight-bold text-primary">Edit Tentang Kami</h6>
                <a class="btn btn-primary" href="<?php echo e(route('tentang-kami.index')); ?>">Back</a>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('tentang-kami.update', $tentangKami->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row g-3">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="title" class="form-label">Title:</label>
                                <input type="text" id="title" name="title" class="form-control" value="<?php echo e($tentangKami->title); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="visi" class="form-label">Visi:</label>
                                <textarea id="visi" name="visi" class="form-control" rows="4" required><?php echo e($tentangKami->visi); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="misi" class="form-label">Misi:</label>
                                <textarea id="misi" name="misi" class="form-control" rows="4" required><?php echo e($tentangKami->misi); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="banner" class="form-label">Current Banner:</label>
                                <?php if($tentangKami->banner): ?>
                                    <div class="mb-2">
                                        <img src="<?php echo e(asset('storage/' . $tentangKami->banner)); ?>" alt="Banner Image" class="img-fluid">
                                    </div>
                                <?php else: ?>
                                    <p>No banner uploaded.</p>
                                <?php endif; ?>
                                <label for="banner" class="form-label">Change Banner (optional):</label>
                                <input type="file" id="banner" name="banner" class="form-control" accept="image/*">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rumahmakan-api\resources\views/tentangkami/edit.blade.php ENDPATH**/ ?>